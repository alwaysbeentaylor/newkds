# 🔧 BACKEND + ADMIN

Backend API + Admin interface in 1 package.

## 🚀 RENDER DEPLOYMENT:

1. Upload deze folder naar Render.com
2. **Web Service** type
3. Build: `npm install`
4. Start: `npm start`
5. Environment Variables:
   ```
   SESSION_SECRET = abc123xyz456
   CLIENT_URL = https://jouw-client.vercel.app
   ```
6. Deploy!

## 📡 URLS:

Na deployment heb je:
- `https://jouw-backend.onrender.com/` → Admin login
- `https://jouw-backend.onrender.com/admin-setup.html` → Setup (1x)
- `https://jouw-backend.onrender.com/admin.html` → Admin panel

**Backend API:** Socket.IO op zelfde URL

## 🔐 TOTP SETUP:

1. Ga naar: `/admin-setup.html`
2. Download Google Authenticator app
3. Scan QR code
4. Done!

## 🧪 LOKAAL TESTEN:

```bash
npm install
npm start
```

Admin: http://localhost:3001/
Setup: http://localhost:3001/admin-setup.html

## 📁 FILES:

- `server.js` - Backend + TOTP
- `public/` - Admin HTML files
- `package.json` - Dependencies
- `.env.example` - Env template
- `render.yaml` - Render config

## ✅ FEATURES:

- TOTP authenticatie (Google Authenticator)
- Socket.IO real-time
- Admin interface included
- CORS voor client
- Session management

**Backend + Admin in 1!** 🔥

## 🔒 SETUP PASSWORD:

**BELANGRIJK!** Setup pagina is nu beschermd met wachtwoord.

In `.env` file:
```env
SETUP_PASSWORD=jouw-veilige-wachtwoord-hier
```

**Setup kan maar 1x!** Na eerste setup:
- Setup endpoint werkt niet meer
- Om opnieuw te doen: verwijder `.totp-secret.json` op server

**VEILIG!** Niemand kan jouw TOTP resetten zonder:
1. Toegang tot server
2. Setup wachtwoord kennen
