// Backend Configuration
// Admin is now served BY the backend, so we connect to same origin
const BACKEND_URL = window.location.origin;

console.log('Backend URL:', BACKEND_URL);
