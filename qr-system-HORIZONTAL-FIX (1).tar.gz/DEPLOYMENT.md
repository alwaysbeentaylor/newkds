# 🎯 QR VERIFICATION - 2 PACKAGES

## 📦 WAT JE HEBT:

```
📱 client-only/      → Klant pagina (Vercel)
🔧 backend-admin/    → Backend + Admin (Render)
```

**2 packages, simpel!**

---

## 🚀 DEPLOYMENT (5 MIN):

### **STAP 1: Backend + Admin (Render) - 3 min**

1. Ga naar: https://render.com
2. New Web Service
3. Upload `/backend-admin` folder
4. Build: `npm install`
5. Start: `npm start`
6. Environment Variables:
   ```
   SESSION_SECRET = abc123xyz456
   SETUP_PASSWORD = jouw-veilige-wachtwoord  ← NIEUW!
   CLIENT_URL = https://jouw-client.vercel.app (vul later in)
   ```
7. Deploy
8. **Kopieer URL:** `https://jouw-backend.onrender.com`

### **STAP 2: Client (Vercel) - 2 min**

1. Ga naar: https://vercel.com
2. New Project
3. Upload `/client-only` folder
4. Deploy
5. **Edit `index.html` regel ~94:**
   ```javascript
   const BACKEND_URL = 'https://jouw-backend.onrender.com';
   ```
6. Redeploy
7. **Kopieer URL:** `https://jouw-client.vercel.app`

### **STAP 3: Backend updaten**

1. Render dashboard → Backend service
2. Environment tab
3. Update:
   ```
   CLIENT_URL = https://jouw-client.vercel.app
   ```
4. Save

### **STAP 4: TOTP Setup**

1. Ga naar: `https://jouw-backend.onrender.com/admin-setup.html`
2. Download Google Authenticator app
3. **Voer SETUP_PASSWORD in** (uit .env)
4. Scan QR code
5. Done!

**LET OP:** Setup kan maar 1x! Na eerste keer is endpoint geblokkeerd. ✅

---

## ✅ URLS NA DEPLOYMENT:

```
Klant:  https://jouw-client.vercel.app
Admin:  https://jouw-backend.onrender.com/
Setup:  https://jouw-backend.onrender.com/admin-setup.html
Panel:  https://jouw-backend.onrender.com/admin.html
```

---

## 🧪 LOKAAL TESTEN (EERST!):

### **Terminal 1 - Backend:**
```bash
cd backend-admin
npm install
npm start
# → http://localhost:3001
```

### **Terminal 2 - Client:**
```bash
cd client-only
npx http-server . -p 3000
# → http://localhost:3000
```

**Test:**
- Klant: http://localhost:3000
- Admin: http://localhost:3001/
- Setup: http://localhost:3001/admin-setup.html

---

## 📋 CHECKLIST:

### **Lokaal testen:**
- [ ] Backend draait op :3001
- [ ] Client draait op :3000
- [ ] TOTP setup werkt
- [ ] Klant kan connecten
- [ ] Admin ziet klanten
- [ ] QR paste werkt

### **Voor deployment:**
- [ ] Backend deployed op Render
- [ ] Client deployed op Vercel
- [ ] `client-only/index.html` → BACKEND_URL updated
- [ ] Render env vars → CLIENT_URL updated
- [ ] TOTP setup gedaan op productie

---

## 🔐 TOTP (Google Authenticator):

1. Download app (gratis)
2. Ga naar `/admin-setup.html`
3. Scan QR code
4. Login met 6-cijferige code
5. Codes veranderen elke 30 sec

**Offline, veilig, simpel!**

---

## 💰 KOSTEN:

- **Vercel (Client):** GRATIS
- **Render (Backend):** GRATIS tier

---

## 🎯 SAMENVATTING:

✅ **2 packages** (client apart, backend+admin samen)
✅ **Vercel ready** (client)
✅ **Render ready** (backend+admin)
✅ **TOTP auth** (Google Authenticator)
✅ **Simpel deployment**
✅ **GRATIS hosting**

**MAKKELIJK, OVERZICHTELIJK, KLAAR!** 🔥
